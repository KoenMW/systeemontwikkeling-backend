
DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `startTime` datetime NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ticket_amount` int(11) NOT NULL,
  `page_id` int(11) DEFAULT NULL,
  `detail_page_id` int(11) DEFAULT NULL,
  `endTime` datetime NOT NULL,
  `eventType` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`),
  KEY `event_typefk` (`eventType`),
  KEY `events_ibfk_2` (`detail_page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

REPLACE INTO `events` VALUES(1, 'Gare du Nord', '2024-07-26 18:00:00', 17.00, 'Patronaat Main Hall', 191, 1, NULL, '2024-07-26 19:00:00', 1);
REPLACE INTO `events` VALUES(4, 'Rilan & The Bombadiers', '2024-07-26 19:30:00', 15.00, 'Patronaat Main Hall', 195, 1, NULL, '2024-07-26 20:30:00', 1);
REPLACE INTO `events` VALUES(6, 'Evolve', '2024-07-26 19:30:00', 15.00, 'Patronaat Main Hall', 300, NULL, NULL, '2024-07-26 20:30:00', 1);
REPLACE INTO `events` VALUES(7, 'Ntjam Rosie', '2024-07-26 21:00:00', 15.00, 'Patronaat Main Hall', 300, NULL, NULL, '2024-07-26 22:00:00', 1);
REPLACE INTO `events` VALUES(8, 'Wicked Jazz Sounds', '2024-07-26 18:00:00', 10.00, 'Patronaat Second Hall', 200, NULL, NULL, '2024-07-26 19:00:00', 1);
REPLACE INTO `events` VALUES(9, 'Tom Thomsom Assemble', '2024-07-26 19:30:00', 10.00, 'Patronaat Second Hall', 200, NULL, NULL, '2024-07-26 20:30:00', 1);
REPLACE INTO `events` VALUES(10, 'Jonna Frazer', '2024-07-26 21:00:00', 10.00, 'Patronaat Second Hall', 200, NULL, NULL, '2024-07-26 22:00:00', 1);
REPLACE INTO `events` VALUES(12, 'Uncle Sue', '2024-07-27 19:30:00', 15.00, 'Patronaat Main Hall', 300, NULL, NULL, '2024-07-27 20:39:00', 1);
REPLACE INTO `events` VALUES(13, 'Myles Sanko', '2024-07-27 18:00:00', 10.00, 'Patronaat Second Hall', 200, NULL, NULL, '2024-07-27 19:00:00', 1);
REPLACE INTO `events` VALUES(14, 'Chris Allen', '2024-07-27 21:00:00', 15.00, 'Patronaat Main Hall', 300, NULL, NULL, '2024-07-27 22:00:00', 1);
REPLACE INTO `events` VALUES(16, 'Fox & The Mayors', '2024-07-27 18:00:00', 15.00, 'Patronaat Main Hall', 300, NULL, NULL, '2024-07-27 19:00:00', 1);
REPLACE INTO `events` VALUES(17, 'Ruis SoundSystem', '2024-07-27 19:30:00', 10.00, 'Patronaat Second Hall', 200, NULL, NULL, '2024-07-27 20:30:00', 1);
REPLACE INTO `events` VALUES(18, 'The family XL', '2024-07-27 21:00:00', 10.00, 'Patronaat Second Hall', 200, NULL, NULL, '2024-07-27 22:00:00', 1);
REPLACE INTO `events` VALUES(19, 'Gare du Nord', '2024-07-28 18:00:00', 15.00, 'Patronaat Main Hall', 300, NULL, NULL, '2024-07-28 19:00:00', 1);
REPLACE INTO `events` VALUES(20, 'Rilan & The Bombadiers', '2024-07-28 19:30:00', 15.00, 'Patronaat Main Hall', 300, NULL, NULL, '2024-07-28 20:30:00', 1);
REPLACE INTO `events` VALUES(22, 'Soul Six', '2024-07-28 21:00:00', 15.00, 'Patronaat Main Hall', 300, NULL, NULL, '2024-07-28 22:00:00', 1);
REPLACE INTO `events` VALUES(23, 'The Nordanians', '2024-07-28 19:30:00', 10.00, 'Patronaat Third Hall', 150, NULL, NULL, '2024-07-28 20:30:00', 1);
REPLACE INTO `events` VALUES(24, 'Ruis Soundsystem', '2024-07-29 15:00:00', 0.00, 'Grote Markt', 0, NULL, NULL, '2024-07-29 16:00:00', 1);
REPLACE INTO `events` VALUES(25, 'Gare du Nord', '2024-07-29 18:00:00', 0.00, 'Grote Markt', 0, NULL, NULL, '2024-07-29 19:00:00', 1);
REPLACE INTO `events` VALUES(26, 'Gumbo Kings', '2024-07-29 17:00:00', 0.00, 'Grote Markt', 0, NULL, NULL, '2024-07-29 18:00:00', 1);
REPLACE INTO `events` VALUES(27, 'The Nordanians', '2024-07-29 16:00:00', 0.00, 'Grote Markt', 0, NULL, NULL, '2024-07-29 17:00:00', 1);
REPLACE INTO `events` VALUES(28, 'Mano Restaurant', '2024-07-26 18:00:00', 10.00, 'Bakenessergracht 109, 2011 JV Haarlem', 30, NULL, NULL, '2024-07-20 19:30:00', 3);
REPLACE INTO `events` VALUES(29, 'Mano Restaurant', '2024-07-26 19:30:00', 10.00, 'Bakenessergracht 109, 2011 JV Haarlem', 30, NULL, NULL, '2024-07-26 21:00:00', 3);
REPLACE INTO `events` VALUES(30, 'Mano Restaurant', '2024-07-26 21:00:00', 10.00, 'Bakenessergracht 109, 2011 JV Haarlem', 30, NULL, NULL, '2024-07-26 22:30:00', 3);
REPLACE INTO `events` VALUES(31, 'Restaurant De Zeeuw', '2024-07-27 18:00:00', 10.00, 'Nassaulaan 1, 2011 PB Haarlem', 30, NULL, NULL, '2024-07-27 19:30:00', 3);
REPLACE INTO `events` VALUES(32, 'Restaurant De Zeeuw', '2024-07-27 19:30:00', 10.00, 'Nassaulaan 1, 2011 PB Haarlem', 30, NULL, NULL, '2024-07-27 21:00:00', 3);
REPLACE INTO `events` VALUES(33, 'Restaurant De Zeeuw', '2024-07-27 21:00:00', 10.00, 'Nassaulaan 1, 2011 PB Haarlem', 30, NULL, NULL, '2024-07-27 22:30:00', 3);
REPLACE INTO `events` VALUES(34, 'Tatsu Haarlem', '2024-07-28 21:00:00', 10.00, 'Oude Groenmarkt 14-16, 2011 HL Haarlem', 30, NULL, NULL, '2024-07-28 22:30:00', 3);
REPLACE INTO `events` VALUES(35, 'Tatsu Haarlem', '2024-07-28 19:30:00', 10.00, 'Oude Groenmarkt 14-16, 2011 HL Haarlem', 30, NULL, NULL, '2024-07-28 21:00:00', 3);
REPLACE INTO `events` VALUES(36, 'Tatsu Haarlem', '2024-07-28 18:00:00', 10.00, 'Oude Groenmarkt 14-16, 2011 HL Haarlem', 30, NULL, NULL, '2024-07-28 19:30:00', 3);
REPLACE INTO `events` VALUES(37, 'English tour', '2024-07-26 10:00:00', 17.50, 'Bavo Church', 12, NULL, NULL, '2024-07-16 12:30:00', 2);
REPLACE INTO `events` VALUES(38, 'English tour', '2024-07-27 10:00:00', 17.50, 'Bavo Church', 12, NULL, NULL, '2024-07-27 12:30:00', 2);
REPLACE INTO `events` VALUES(39, 'English tour', '2024-07-28 10:00:00', 17.50, 'Bavo Church', 12, NULL, NULL, '2024-07-28 12:30:00', 2);
REPLACE INTO `events` VALUES(40, 'English tour', '2024-07-29 10:00:00', 17.50, 'Bavo Church', 12, NULL, NULL, '2024-07-29 12:30:00', 2);
REPLACE INTO `events` VALUES(41, 'Nicky Romero / Afrojack', '2024-07-26 20:00:00', 75.00, 'Lichtfabriek', 1500, 4, NULL, '2024-07-26 23:00:00', 4);
REPLACE INTO `events` VALUES(42, 'Nicky Romero', '2024-07-27 23:00:00', 60.00, 'Club Stalker', 200, NULL, NULL, '2024-07-28 04:00:00', 4);
REPLACE INTO `events` VALUES(43, 'Hardwell', '2024-07-28 21:00:00', 90.00, 'XO the Club', 1500, NULL, NULL, '2024-07-28 23:00:00', 4);
