
DROP TABLE IF EXISTS `detail_page`;
CREATE TABLE IF NOT EXISTS `detail_page` (
  `page_id` int(11) NOT NULL,
  `parent_page_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `page_id` (`page_id`),
  KEY `detail_page_ibfk_1` (`parent_page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

REPLACE INTO `detail_page` VALUES(9, 1);
