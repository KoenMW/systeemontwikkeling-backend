
DROP TABLE IF EXISTS `eventType`;
CREATE TABLE IF NOT EXISTS `eventType` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

REPLACE INTO `eventType` VALUES(1, 'Jazz');
REPLACE INTO `eventType` VALUES(2, 'History');
REPLACE INTO `eventType` VALUES(3, 'Yummy');
REPLACE INTO `eventType` VALUES(4, 'Dance');
