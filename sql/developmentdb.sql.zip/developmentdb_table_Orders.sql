
DROP TABLE IF EXISTS `Orders`;
CREATE TABLE IF NOT EXISTS `Orders` (
  `id` varchar(23) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `paymentDate` date DEFAULT NULL,
  `checkedIn` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

REPLACE INTO `Orders` VALUES('65ef324f0e1836.47147373', 1, 5, 2, '', '2024-04-07', b'0');
REPLACE INTO `Orders` VALUES('65ef32a0b82d25.11475413', 1, 5, 2, '', NULL, b'0');
REPLACE INTO `Orders` VALUES('65ef33223cd3f5.54606502', 1, 5, 2, '', '2024-03-28', b'0');
REPLACE INTO `Orders` VALUES('65ef3327520141.29808749', 1, 5, 2, '', '2024-03-28', b'0');
REPLACE INTO `Orders` VALUES('65ef332a5c0577.71884554', 1, 5, 2, '', '2024-03-28', b'0');
REPLACE INTO `Orders` VALUES('65ef337112cfd5.71212646', 1, 5, 2, '', NULL, b'0');
REPLACE INTO `Orders` VALUES('65ef33830ab194.64343561', 1, 5, 2, '', NULL, b'0');
REPLACE INTO `Orders` VALUES('65ef3397c73777.35846103', 1, 5, 2, '', NULL, b'0');
REPLACE INTO `Orders` VALUES('65ef34cea8eeb7.61936709', 1, 5, 2, '', NULL, b'0');
REPLACE INTO `Orders` VALUES('6612551fecd889.90261037', 1, 13, 9, '', '2024-04-07', b'0');
REPLACE INTO `Orders` VALUES('66125520164657.38300878', 4, 13, 5, '', '2024-04-07', b'0');
REPLACE INTO `Orders` VALUES('661255201a6c58.39409493', NULL, 13, 2, '', '2024-04-07', b'0');
REPLACE INTO `Orders` VALUES('66125520200273.83027583', NULL, 13, 1, '', '2024-04-07', b'0');
