
DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

REPLACE INTO `pages` VALUES(0, 'home');
REPLACE INTO `pages` VALUES(1, 'Jazz');
REPLACE INTO `pages` VALUES(2, 'History');
REPLACE INTO `pages` VALUES(3, 'Yummy');
REPLACE INTO `pages` VALUES(4, 'Dance');
REPLACE INTO `pages` VALUES(9, 'Gare du Nord');
